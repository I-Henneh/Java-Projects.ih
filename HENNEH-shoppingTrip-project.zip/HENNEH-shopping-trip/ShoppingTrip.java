import java.util.ArrayList;
/**
 * The ShoppoingTrip class allows a list of food items to be
 * operated on
 *
 * @author    Ivan Henneh
 * @version   03/06/2024
 */
public class ShoppingTrip
{
    // Declares an ArrayList of String field called food.
    private ArrayList<String> foods;

    /**
     * Constructor for objects of class ShoppingTrip to instantiate
     * the foods field.
     */
    public ShoppingTrip()
    {
        // initialise a new ArrayList object which is assigned to food
        foods = new ArrayList<String>();
    }

    /**
     * An acessor method which would return the String value for our 
     * index in foods collection.
     *
     * @param   index   index input by user to get its String value.
     * @return          the number of elements stored in food collection.
     */
    public ArrayList<String> getFoods(int index)
    {
        // return String value of particular index
        return foods;
    }
    
    /**
     * An acessor method to get number of elements stored inside the
     * foods collection.
     * 
     * @return  the number of elements stored in the foods collection.
     */
    public int getNumberofFoods()
    {
        // return numberof elements.
        return foods.size();
    }
    
    /**
     * An acessor method to add a String food name to the foods collection.
     * 
     * @param  foodName  would check for food name to be added to collection.
     * 
     * @return true      if the 'if' condition set is true and prints a valid message.
     * 
     * @return false     if the 'else' condition is true and prints an error message.
     */
    public boolean addFood(String foodName)
    {
        if (foodName != null)
        {
            System.out.println("ADDED " + foodName);
            return foods.add(foodName);
        }
        else
        {
            System.out.println("ERROR: can NOT add invalid food.");
            return false;
        }
    }
    
    /**
     * A mutator method that would add a valid food item to the begining of
     * the foods collection as the very first element.
     * 
     * @param index    would take a valid index from user to store food items.
     * 
     * @param foodName would take food name from user and add to foods collection.
     */
    public void addFood(int index, String foodName)
    {
        if(index >=0 && index < foods.size() && foodName != null)
        {
            System.out.println("ADDED " + foodName + "at index " + index);
        }
        else
        {
            System.out.println("ERROR: can NOT add with invalid index/food");
        }
    }
    
    /**
    * A mutator method that adds a valid food item at the begining
    * of the foods collection as the very first element.
    * 
    * @param foodName would take valid food name from user and add to
    * collection.
    */
    public void addFoodFirst(String foodName)
    {
        if(foodName != null)
        {
            System.out.println("ADDED " + foodName + " as first item");
            foods.add(0,foodName);
        }
        else
        {
            System.out.println("ERROR: can NOT add invalid food");
        }
            
    }
    
    /**
     * A mutator method that removes an ited from the food collection if
     * stored at a valid index.
     * 
     * @param index  would take valid index value from user and remove its
     * stored food item.
     */
    public void removeFood(int index, String foodName)
    {
        if(index >=0 && index < foods.size())
        {
            System.out.println("REMOVED " + foodName + " from index " + index);
            
        }
        else
        {
            System.out.println("No food found at index " + index);
        }
    }
    
    /**
     * An acessor method to remove a food item from the food collection at 
     * a specified index.
     * 
     * @param  foodName takes the name of the food to be removed from user.
     * 
     * @return         returns the result of a sucessful removal of food item.
     * @return         returns false if foodNmae is invalid/null
     */
    public boolean removeFood(String foodName)
    {
        if(foodName != null)
        {
            System.out.println("REMOVED " + foodName);
            return foods.remove(foodName);
        }
        else
        {
            System.out.println("ERROR: can NOT remove invalid food");
            return false;
        }
    }
    
    /**
     * A mutator method that lists and prints allfood items in sequence from
     * the foods collection if not empty.
     */
    public void listAllFoods()
    {
        if (foods.isEmpty())
        {
            System.out.println("NO food items to list");
        }
        else
        {
            System.out.println("Food items: ");
            for(String foodName : foods)
            {
                System.out.println(foodName);
            }
        }
    }
    
    /**
     * A mutator method that would only print food items in the foods 
     * collection that contains the searchFood string regardless.
     * 
     * @param searchFood would take the String value from user and search
     * whether the searchFood is part of the collection.
     */
    public void listFoodMatching(String searchFood)
    {
        boolean noMatch = false;
        System.out.println("Food items containing " + searchFood);
        for(String fooditems : foods)
        {
            if(fooditems.toUpperCase().contains(searchFood))
            {
                System.out.println(fooditems);
                noMatch = false;
            }
            else
            {
                noMatch = true;
            }
        }
        
        if(noMatch == true)
        {
            System.out.println("NO food contains " + searchFood);
        }
    }
    }
    
        
    
    
    

