

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The test class ShoppingTripTest.
 *
 * @author    Ivan Henneh
 * @version   03/07/2023
 */
public class ShoppingTripTest
{
    private ShoppingTrip myShopping;
    
    /**
     * Default constructor for test class ShoppingTripTest
     */
    public ShoppingTripTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @BeforeEach
    public void setUp()
    {
        myShopping = new ShoppingTrip();
        myShopping.addFood("milk");
        myShopping.addFood("eggs");
        myShopping.addFood("bread");
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @AfterEach
    public void tearDown()
    {
    }

    @Test
    public void myShopping()
    {
    }
}

