/**
 * A duck is any of various species of relatively small, short-necked, large-billed waterfowl.
 *
 * @author   Henneh Ivan Yaw
 * @version  09/20/2023
 */
public class Duck extends Animal 
{
    public Duck(double weight, String name)
    {
        super(weight, name);
    }

    @Override
    public void sound() 
    {
        System.out.println("Quack!, Quack!!");
    }

    @Override
    public void eat() 
    {
        System.out.println("Eating Duck Feed");
    }
}
