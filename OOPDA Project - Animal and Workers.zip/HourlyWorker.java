/**
 * Write a description of class HourlyWorker here.
 *
 * @author   Henneh Ivan Yaw
 * @version  09/23/2023
 */
public class HourlyWorker extends Person 
{
    private double hoursWorked;
    private double hourlyPayRate;

    public HourlyWorker(int id, String lastName, double hoursWorked, double hourlyPayRate) 
    {
        super(id, lastName);
        this.hoursWorked = hoursWorked;
        this.hourlyPayRate = hourlyPayRate;
    }

    @Override
    public double computeSalary() 
    {
        double regularPay;
        double overtimePay;
        double totalPay;
        
        if (hoursWorked <= 40)
        {
            regularPay = hoursWorked * hourlyPayRate;
            overtimePay = 0.0;
        }
        else
        {
            regularPay = 40 * hourlyPayRate;
            overtimePay = (hoursWorked - 40) * (hourlyPayRate * 1.5);
        }
        return regularPay + overtimePay;
    }
    
    @Override
    public String toString()
    {
        return super.toString() + " " + computeSalary();
    }
}
