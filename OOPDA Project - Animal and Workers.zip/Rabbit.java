/**
 * A rabbit is any of various long-eared, short-tailed, burrowing mammals of the family Leporidae
 *
 * @author   Henneh Ivan Yaw
 * @version  09/20/2023
 */
public class Rabbit extends Animal 
{
    public Rabbit(double weight, String name) 
    {
        super(weight, name);
    }

    @Override
    public void sound() 
    {
        System.out.println("Squeak!, Squeak!!");
    }

    @Override
    public void eat() 
    {
        System.out.println("Eating Fresh Vegetables and Hay");
    }
}
