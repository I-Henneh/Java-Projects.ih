
/**
 * Write a description of class CommisionedWorker here.
 *
 * @author   Henneh Ivan Yaw
 * @version  09/20/2023
 */
public class CommissionedWorker extends Person 
{
    private double totalSales;
    private double commissionRate;

    public CommissionedWorker(int id, String lastName, double totalSales, double commissionRate) 
    {
        super(id, lastName);
        this.totalSales = totalSales;
        this.commissionRate = commissionRate;
    }

    @Override
    public double computeSalary() 
    {
        double totalPay = totalSales * commissionRate;
        return totalPay;
    }
    
    @Override
    public String toString()
    {
        return super.toString() + " " + computeSalary();
    }
}
