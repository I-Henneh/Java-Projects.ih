/**
 * Write a description of class Intern here.
 *
 * @author   Henneh Ivan Yaw
 * @version  09/20/2023
 */
public class Intern extends Person 
{
    private double weeklyPay;

    public Intern(int id, String lastName, double weeklyPay) 
    {
        super(id, lastName);
        this.weeklyPay = weeklyPay;
    }

    @Override
    public double computeSalary() 
    {
        return weeklyPay;
    }
    
    @Override
    public String toString()
    {
        return super.toString() + " " + computeSalary();
    }
}