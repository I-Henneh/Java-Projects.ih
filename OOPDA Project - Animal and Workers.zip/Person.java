/**
 * a Person is an identified human being.
 *
 * @author   Henneh Ivan Yaw
 * @version  09/23/2023
 */
public abstract class Person 
{
    protected int id;
    protected String lastName;

    public Person(int id, String lastName) 
    {
        this.id = id;
        this.lastName = lastName;
    }

    public abstract double computeSalary();

    public int getId() 
    {
        return id;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    public String getLastName() 
    {
        return lastName;
    }

    public void setLastName(String lastName) 
    {
        this.lastName = lastName;
    }

    @Override
    public String toString() 
    {
        return (this.id + " " + this.lastName);
    }
}
