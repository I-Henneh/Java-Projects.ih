
/**
 * A dog is a domestic mammal belonging to the family Canidae and order Carnivora.
 *
 * @author   Henneh Ivan Yaw
 * @version  09/20/2023
 */
public class Dog extends Animal
{
    public Dog(double weight, String name)
    {
        super(weight, name);
    }

    @Override
    public void sound()
    {
        System.out.println("Bark!, Bark!");
    }
    
    @Override
    public void eat() 
    {
        System.out.println("Eating Purina Pro Plan High Protein Dog Food");
    }
}