/**
 * A cat is a domestic mammal of family Felidae and genus Felis.
 *
 * @author   Henneh Ivan Yaw
 * @version  09/20/2023
 */
public class Cat extends Animal 
{
    public Cat(double weight, String name) 
    {
        super(weight, name);
    }

    @Override
    public void sound() 
    {
        System.out.println("Meow!, Meow!!");
    }

    @Override
    public void eat() 
    {
        System.out.println("Eating Friskies Seafood Sensations cat food");
    }
}
