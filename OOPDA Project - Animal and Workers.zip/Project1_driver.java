/**
 * Project 1
 *
 * @author   Henneh Ivan Yaw
 * @version  09/20/2023
 */
import java.util.List;
import java.util.ArrayList;

public class Project1_driver {
    public static void main(String[] args) {
        System.out.println("Project1, Henneh Ivan Yaw, student id = 9999999");

        P1();
        P2();
    }

    static void P1() {
        List<Animal> pets = new ArrayList<>();

        pets.add(new Dog(12.0, "Rover"));
        pets.add(new Cat(7, "Felix"));
        pets.add(new Cat(6.5, "Garfield"));
        pets.add(new Dog(15, "Ren"));
        pets.add(new Dog(14, "Astro"));
        pets.add(new Rabbit(4, "Thumper")); // Adding a Rabbit pet

        for (Animal pet : pets) {
            System.out.println("The pet's name is " + pet.getName());
            System.out.println("It weighs " + pet.getWeight());
            pet.sound();
            pet.eat();
            System.out.println();
        }

        for (Animal pet : pets) {
            double weight = pet.getWeight();
            weight += 0.5;
            pet.setWeight(weight);
        }

        System.out.println("-----------------------------------------\n");
        System.out.println("After the pets have been eating the great pet food for a month!!!");

        for (Animal pet : pets) {
            System.out.println("The pet's name is " + pet.getName());
            System.out.println("It weighs " + pet.getWeight());
            pet.sound();
            pet.eat();
            System.out.println();
        }
    }

    static void P2() {
        List<Person> people = new ArrayList<>();

        people.add(new HourlyWorker(101, "Smith", 50, 10.25));
        people.add(new CommissionedWorker(123, "Jones", 10000.0, 0.10));
        people.add(new Intern(120, "Wilson", 120.00));
        people.add(new HourlyWorker(103, "Williams", 50, 20.25));
        people.add(new CommissionedWorker(140, "Decker", 35000.0, 0.10));
        people.add(new Intern(129, "Brown", 105.00));
        people.add(new HourlyWorker(113, "Miller", 55, 30.25));
        people.add(new CommissionedWorker(150, "Davis", 15000.0, 0.20));
        people.add(new Intern(180, "Adams", 100.00));
        people.add(new HourlyWorker(119, "Murphy", 55, 30.50));

        for (Person person : people) {
            System.out.println(person);
        }

        System.out.println();
        System.out.println("id             Name    Salary");
        for (Person person : people) {
            System.out.printf("%d %15s  $%8.2f\n", person.getId(), person.getLastName(), person.computeSalary());
        }
    }
}

