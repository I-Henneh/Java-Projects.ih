
/**
 * An animal is a multicellular eukaryote with cells bound together by collagen.
 *
 * @author   Henneh Ivan Yaw
 * @version  09/20/2023
 */
public abstract class Animal {
    // declare variables name and weight
    private String name;
    private double weight;

    /**
     * Constructor for objects of class Animal
     * 
     * @param  name    for name of animal
     * @param  weight  for weight of animal
     */
    public Animal(double weight, String name)
    {
        // initialise instance variables
        this.name = name;
        this.weight = weight;
    }
    
    /**
     * An abstract sound method - describes the sound of an animal
     * An abstract eat method - describes the food an animal eats
     */
    public abstract void sound();
    
    public abstract void eat();
    
    /**
     * An accessor method getName() - to return the name of the animal
     * 
     * @return  name
     */
    public String getName()
    {
        return name;
    }
    
    /**
     * An accessor method getWeight() - to return the weight of the animal
     * 
     * @return  weight
     */   
    public double getWeight() 
    {
        return weight;
    }

    /**
     * A mutator method setName() - to set the name of the animal
     * 
     * @param name the name to set
     */
    public void setName(String name)
    {
        this.name = name;
    }

    /**
     * A mutator method setWeight() - to set the weight of the animal
     * 
     * @param weight the weight to set
     */
    public void setWeight(double weight)
    {
        this.weight = weight;
    }
}
