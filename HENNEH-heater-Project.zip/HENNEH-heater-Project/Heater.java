/**
 * The Heater class stimulates a heater where the
 * temperature may be between a min and max amount.
 * The temperature may also be changed to be warmer
 * or cooler by an increment amount which may also be set.
 *
 * @author    Ivan Henneh
 * @version  02/13/23
 */
public class Heater
{
    private double temperature;                     // the current temperature
    private double min;                             // the minimum temperature
    private double max;                             // the maximum temperature
    private double increment;                       // the increment value of the temperature

    /**
     * Create a new Heater with some initial temperature.
     * Initialize the temparature and increment values.
     * 
     * @param  minimum           the minimum possible temperature
     * @param  maximum           the maximum possible temperature
     */
    public Heater(double minimum, double maximum)
    {
        min = minimum;                                    // the minimum temperature
        max = maximum;                                    // the maximum temperature
        temperature = 15.0;                               // temperature initialised to 15.0
        increment = 5.0;                                  // increment value initialised to 5.0
    }

    /**
     * increases current temperature of the Heater 
     */
    public void warmer()
    {
        double newTemperature = temperature + increment;     
        if(newTemperature <= max)
        { 
            temperature = newTemperature;
        }
    }
    
    /**
     * Decreases current temperature
     */
    public void cooler()
    {
        double newTemperature = temperature - increment;
        if(newTemperature >= min)
        {
            temperature = newTemperature;
        }
    }
    
    /**
     * Sets the increment value to determine how the 
     * warmer() and cooler() methods change the temperature.
     * 
     * @param  inc               the increment value  
     */
    public void setIncrement(double inc)
    {
        if(inc >= 0)
        {
            increment = inc;
        }
    }
    
    /**
     * Gets the current temperature of the heater.
     * 
     * @return  temperature      the current temperature
     */
    public double getTemperature()
    {
        return temperature;
    }
}

