
/**
 * The card class stores the details of a card using the player's name and year.
 *
 * @author   Henneh Ivan Yaw
 * @version  03/20/2023
 */
public class Card
{
    // instance variables for player and year fields.
    private String player;
    private int year;

    /**
     * Constructor for objects of class Card to initialize and store the details of
     * a card
     * 
     * @param player   a String field for the player's name on card.
     * @param year     an int field for the player's year.
     */
    public Card(String player, int year)
    {
        // initialise instance variables
        setDetails(player, year);
    }

    /**
     * An accessor method to get and return String value of player field.
     *
     * @return    the player's name stored in player field.
     */
    public String getPlayer()
    {
        // put your code here
        return player;
    }
    
    /**
     * An accessor method to get and return int value of year fiel
     * 
     * @return    player's year stored in year field.
     */
    public int getYear()
    {
        return year;
    }
    
    /**
     * An accessor method to get and return the details on the card
     * 
     * @return    the details(player name and year) on card
     */
    public String getDetails()
    {
        return "" + player + " (" + year + ")";
    }
    
    /**
     * A  private mutator method to help constructor store values in
     * the fields
     * 
     * @param player  a String field for player name.
     * @param year    an int field for player year.  
     */
    private void setDetails(String player, int year)
    {
        this.player = player;
        this.year = year;
    }
}
