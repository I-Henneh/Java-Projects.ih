import java.util.ArrayList;
/**
 * The CardCollection class stores the card class objects inside it using
 * an ArrayList of cards object collection.
 *
 * @author  Henneh Ivan Yaw;
 * @version 03/20/2023
 */
public class CardCollection
{
    // instance variables - replace the example below with your own
    private String collectorName;
    private ArrayList<Card> cards;

    /**
     * Constructor to initialize collectorName field to input parameter and 
     * instantiate cards field to a new ArrayList.
     * 
     * @param collectorName  takes name of collector and initialize it.
     */
    public CardCollection()
    {
        // initialise instance variables
        this.collectorName = collectorName;
        cards = new ArrayList<Card>();
    }
    
    /**
     * An accessor method to get and return values stored in collectorName field
     * 
     * @return   String value(name) of the collector 
     */
    public String getcollectorName()
    {
        return collectorName;
    }
    
    /**
     * An accessor method to get and retun the ArrayList of cards objects
     * for the card collection.
     * 
     * @return   the ArrayList of card for the cards field
     */
    public ArrayList<Card> getCards()
    {
        return cards;
    }
    
    /**
     * An accessor method without a parameter to get and return the number 
     * of cards in the cards ArrayList
     * 
     * @return   number of cards in ArrayList of cards.
     */
    public int getNumberOfCards()
    {
        return cards.size();
    }
    
    /**
     * Private method to determine whether the given index is valid for the collection and 
     * prints an error message if negative or too large.
     * 
     * @param index    needs to be checked if positive and not too large.
     * @return         true if index is valid and false if index is invalid.  
     */
    private boolean indexValid(int index)
    {
        boolean valid = true;
        
        if(index < 0 )
        {
            System.out.println("Index cannot be negative: " + index);
            valid = false;
        }
        
        else if(index >= cards.size())
        {
            System.out.println("Index is too large: " + index);
            valid = false;
        }
        else 
        {
            return valid;
        }
        
        return valid;
    }
    
    /**
     * A method that takes a Card object as the parameter and store in
     * a variable called card. It would then add the card object to the cards ArrayList
     * collection if the value is null.
     * 
     * @param Card   of data type Card which would be added to the ArrayList if
     *               the value is null.
     */
    public void addCard(Card card)
    {
        if(card != null)
        {
            cards.add(card);
            System.out.println("Added card: " + card.getDetails());
        }
        else
        {
            System.out.println("Invalid card cannot be added");
        }
    }
    
    /**
     * A method that would take an integer value and store it 
     * inside a variable called index and then remove the card from the ArrayList
     * if the index is valid
     * 
     * @param index   The index at which the card object is located at so that it
     *                could get removed only if it's valid.
     */
    public void removeCard(int index)
    {
        if(indexValid(index))
        {
            cards.remove(index);
            System.out.println("Removed card: " + cards.remove(index).getDetails());
        }
        else
        {
            System.out.println("NO card to remove at index: " + index);
        }
    }
    
    /**
     * A method that would take an integer value and store it in a variable
     * called index. The card details at that particular index would be printed
     * only if the index is valid
     * 
     * @param index  The index of the card object to be printed onto the terminal.
     */
    public void listCard(int index)
    {
        if(indexValid(index))
        {
            System.out.println(cards.get(index).getDetails());
        }
        else
        {
            System.out.println("Invalid index: " + index);
        }
    }
    
    /**
     * A method with no parameters to print ALL the cards in the the cards ArrayList   
     */
    public void listAllCards()
    {
       if(cards.isEmpty())
       {
           System.out.println("There are NO cards to print");
       }
       else
       {
           System.out.println("Card listing: ");
           for(Card card : cards)
           {
               System.out.println(card.getDetails());
           }
       }
    }
    
    /**
     * A method with String player parameter to search for All cards containing
     * the player STring in the ArrayList of cards.
     * 
     * @param player  the name of the player on the card that would be searched
     */
    public void listByPlayer(String player)
    {
        boolean found = false;
        for(Card card : cards)
        {
            card.getPlayer();
            if(card.getPlayer().equalsIgnoreCase(player))
            {
                System.out.println(card.getDetails());
                found = true;
            }
        }
        
        if(!found)
        {
            System.out.println("NO cards found for player: " + player);
        }
    }
    
    /**
     * A method with int year parameter which searchs entire card collection
     * for cards with matching years.
     * 
     * @param year  an int value that would be searched and printed if matching value
     * found.
     */
    public void listByYear(int year)
    {
        boolean found = false;
        for(Card card : cards)
        {
            card.getYear();
            if(card.getYear() == year)
            {
                System.out.println(card.getDetails());
                found = true;
            }
        }
        
        if(!found)
        {
        System.out.println("NO cards found for year: " + year);
        }
    }
    
    /**
     * A method with String searchString parameter to search the cards ArrayList and return 
     * the index of ONLY the FIRST card found containing the given searchString parameter.
     * 
     * @param  searchString  A string value that would be searched for through the card collection
     *                      and return only the index of the first card containing the searchString
     *                     
     * @return -1 if no player card is found that conatins the searchString                     
     */
    public int findFirstPlayer(String searchString)
    {
        int index = 0;
        boolean searching = true;
        while(searching && index < cards.size())
        {
            String playerDetails = cards.get(index).getPlayer();
            if(playerDetails.contains(searchString))
            {
                searching = false;
            }
            else
            {
                index++;
            }
        }
        
        if(searching)
        {
            System.out.println("NO player card for: " + searchString);
            return -1;
        }
        else
        {
            System.out.println("Player card for: " + searchString + " at index " + index);
            return index;
        }
    }
}
    
