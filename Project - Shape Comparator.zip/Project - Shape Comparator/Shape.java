
/**
 * An abstract class Shape that  
 *
 * @author   Henneh Ivan Yaw
 * @version  09/21/2023
 */
public abstract class Shape implements Comparable<Shape>
{
    // instance variables - replace the example below with your own
    private double x;
    private double y;

    /**
     * Constructor for objects of class Shape
     */
    public Shape(double x, double y)
    {
        // initialise instance variables
        this.x = x;
        this.y = y;
    }

    /**
     * An accessor method getX() to return the position of x
     *
     * @return    the sum of x and y
     */
    public double getPosX()
    {
        // put your code here
        return x;
    }
    
    /**
     * An accessor method getY() to get and return the position of y.
     */
    public double getPosY()
    {
        return y;
    }
    
    /**
     * 
     */
    public void setPosX(double x)
    {
        this.x = x;
    }
    
    /**
     * 
     */
    public void setPosY(double y)
    {
        this.y = y;
    }
    
    /**
     * 
     */
    public abstract double ComputeArea();
    
    /**
     *
     */
    public abstract double ComputePerimeter();
    
    /**
    * 
    */
    @Override
    public int compareTo(Shape otherShape)
    {
        double thisArea = this.ComputeArea();
        double otherArea = otherShape.ComputeArea();
        return Double.compare(thisArea, otherArea);
    
    }
}
