import java.util.Collections;
import java.util.ArrayList;
import java.util.*;
/**
 * Project 2
 * 
 * @author   Henneh Ivan Yaw  
 * @version  09/25/2023
 */

public class Project2_Driver
{
    public static void main(String[] args)
    {
        P1();
    }

 
    static void P1()
    {
        Circle c;
        Rectangle r;

        Shape[] shapesList = new Shape[4];

        c = new Circle(20, 0, 10.0);
        shapesList[0] = c;

        c = new Circle(40, 10, 4.0);
        shapesList[1] = c;

        r = new Rectangle(50, 20, 5.0, 6.0);
        shapesList[2] = r;

        r = new Rectangle(30, 20, 5.0, 16.0);
        shapesList[3] = r;
        
        System.out.println();
        System.out.println("Original Ordering");
        for (int i = 0; i < 4; i++) 
        {    
            System.out.println(shapesList[i]);       
        }

        System.out.println(c.compareTo(r));
        // Sort by area using the Capmparable Interface
        Arrays.sort(shapesList);

        System.out.println();
        System.out.println("Sorted by area");
        for (int i = 0; i < 4; i++)
        {
            System.out.println(shapesList[i]);       
        }
        
        // Sort by the x position via student implementation of the the Comparator Interface
        Arrays.sort(shapesList, new ShapeXPosComparator());
        
        System.out.println();
        System.out.println("Sorted by x position");
        for (int i = 0; i < 4; i++)
        { 
            System.out.println(shapesList[i]);      
        }
        
        // Sort by the x position via student implementation the Comparator Interface
        
        Arrays.sort(shapesList, new ShapePerimeterComparator());
        
        System.out.println();
        System.out.println("Sorted by perimeter");
        for (int i = 0; i < 4; i++) 
        {
            System.out.println(shapesList[i]);      
        }


    }    
}