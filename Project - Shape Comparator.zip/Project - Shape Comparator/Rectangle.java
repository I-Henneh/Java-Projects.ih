/**
 * Write a description of class Rectangle here.
 *
 * @author   Henneh Ivan Yaw
 * @version  09/21/2023
 */
public class Rectangle extends Shape
{
    // instance variables - replace the example below with your own
    private double length;
    private double width;

    /**
     * Constructor for objects of class Rectangle
     */
    public Rectangle(double x, double y, double length, double width)
    {
        // initialise instance variables
        super(x, y);
        this.length = length;
        this.width = width;
        
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    @Override
    public double ComputeArea()
    {
        // put your code here
        double Area = length * width;
        return Area;
    }
    
    /**
     * 
     */
    @Override
    public double ComputePerimeter()
    {
       double Perimeter = 2*length + 2*width;
       return Perimeter;
       
    }
    
    /**
     * @return  String
     */
    @Override
    public String toString()
    {
        return "Rectangle: x = " + getPosX() + " , y = " + getPosY() + ", Area = " + ComputeArea() + ", Perimeter = " + ComputePerimeter();
    }
     
    

}