import java.util.Comparator;
/**
 * Write a description of interface ShapeXPosComparator here.
 *
 * @author   Henneh Ivan Yaw
 * @version  09/25/2023
 */
public class ShapeXPosComparator implements Comparator<Shape> {
    @Override
    public int compare(Shape shape1, Shape shape2) 
    {
        double xPos1 = shape1.getPosX();
        double xPos2 = shape2.getPosX();
        return Double.compare(xPos1, xPos2);
    }
}