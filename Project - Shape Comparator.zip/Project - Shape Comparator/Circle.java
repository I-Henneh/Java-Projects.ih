/**
 * Write a description of class Rectangle here.
 *
 * @author   Henneh Ivan Yaw
 * @version  09/21/2023
 */
public class Circle extends Shape
{
    // instance variables - replace the example below with your own
    private double radius;
    private static final double pi = 3.143;

    /**
     * Constructor for objects of class Rectangle
     */
    public Circle(double x, double y, double radius)
    {
        // initialise instance variables
        super(x, y);
        this.radius = radius;
        
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    @Override
    public double ComputeArea()
    {
        // put your code here
        double Area = pi * radius * radius;
        return Area;
    }
    
    /**
     * 
     */
    @Override
    public double ComputePerimeter()
    {
       double Perimeter = 2 * pi * radius;
       return Perimeter;
       
    }
    
    /**
     * 
     */
    @Override
    public String toString() {
        return "Circle: x = " + getPosX() + ", y = " + getPosY() + ", Area = " + ComputeArea() + ", Perimeter = " + ComputePerimeter();
    }
}
