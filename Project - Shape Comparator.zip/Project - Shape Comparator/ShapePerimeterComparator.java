import java.util.Comparator;
/**
 * This class is to compare the perimeter of shapes.
 *
 * @author   Henneh Ivan Yaw
 * @version  09/25/2023
 */
class ShapePerimeterComparator implements Comparator<Shape> {
    @Override
    public int compare(Shape shape1, Shape shape2) {
        double perimeter1 = shape1.ComputePerimeter();
        double perimeter2 = shape2.ComputePerimeter();
        return Double.compare(perimeter1, perimeter2);
    }
}
