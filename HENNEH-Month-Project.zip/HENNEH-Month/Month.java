
/** The Month class displays the name of the month
 *  of the year corresponding to the input number 
 *  of the month between 1 and 12 inclusive.
 * 
 *
 *  @author  Ivan Henneh
 *  @version 02/14/2023
 */
public class Month
{
    private int monthNumber;                                       // the number of the month
    private String monthName;                                      // the name of the month
    
    /**
     * Initializes the the monthNumber field to newMonthNum
     * and sets conditins for number to be valid only
     * when it's between 1 and 12.
     * 
     * @param   newMonthNum                  the number of the month of the year.
     */
    public Month(int newMonthNum)
    {
        monthNumber = newMonthNum;
        if(newMonthNum == 0 || newMonthNum > 12) 
        {
            System.out.println("ERROR: Month " + monthNumber + " must be between 1 and 12.");
        }
        else if(newMonthNum < 0)
        {
            System.out.println("ERROR: Month " + monthNumber + " must be positive.");
        }
        else
        {
            System.out.println("Month " + monthNumber + " is VALID.");
        }  
        setMonthName();
        printMonth();
    }
    
    /**  Gets the month number 
     * 
     * @ return       monthNumber            the number of the month of the year. 
     */
    public int getMonthNumber()
    {
        return monthNumber;
    }
    
    /**  Gets the month name
     * 
     * @ return       monthName              the name of the month of the year.
     */
    public String getmonthName()
    {
        return monthName;
    }
    
    /** Sets the month name depending on some cases with
     *  regards to the month number input.
     * 
     *  @param         monthNumber            the number of the month of the year.
     */
    
    private void setMonthName()
    {
        switch(monthNumber)
        {
        
        case 1:  monthName = "January";
                 break;
        case 2:  monthName = "February";
                 break;
        case 3:  monthName = "March";
                 break;
        case 4:  monthName = "April";
                 break;
        case 5:  monthName = "May";
                 break;
        case 6:  monthName = "June";
                 break;
        case 7:  monthName = "July";
                 break;
        case 8:  monthName = "August";
                 break;
        case 9:  monthName = "September";
                 break;
        case 10: monthName = "October";
                 break;
        case 11: monthName = "November";
                 break;
        case 12: monthName = "December";
                 break;
        default: monthName = "an Invalid month"; 
                 break;
        }
    } 
    
     /** Prints the name of the month
     * 
     */
    public void printMonth()
    {
        System.out.println("Month " + monthNumber + " is " + monthName + ".");
    }
    }